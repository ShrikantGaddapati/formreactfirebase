import React, { useState } from "react";
import { db } from "../firebase";

const Form = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
    const [option, setOption] = useState("");

  const [load, setloader] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setloader(true); //on submit set load to true
    db.collection("forms")
      .add({
        name: name,
        email: email,
          message: message,
        option:option
      })
      .then(() => {
        alert("subkmitted successfully");
        setloader(false);
      })
      .catch((error) => {
        alert("error in submitting");
      });

    setName("");
    setEmail("");
    setMessage("");
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <h1>Please fill the following form </h1>
      <label>Name</label>
      <input
        placeholder="name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      ></input>
      <label>Email</label>
      <input
        placeholder="email"
        value={email}
        required
        onChange={(e) => setEmail(e.target.value)}
      ></input>
      <label>Message</label>
      <textarea
        placeholder="message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        required
      ></textarea>
          <select name="selectList" id="selectList" onChange={(e) => setOption(e.target.value)}>
          <option value={option}>Male</option> {" "}
              <option value={option}>Female</option>
      </select>
      <button
        type="submit"
        style={{ background: load ? "#gray" : "red" }}
        required
      >
        Submit
      </button>
    </form>
  );
};

export default Form;
